# People who have contributed
______________

## Collaborators
- <a href="https://github.com/mvrozanti">Nexor (@mvrozanti)</a>
- <a href="https://github.com/dudeisbrendan03">Brendan (@dudeisbrendan03)</a>

## Supporters (Contributors with PRs)
- <a href="https://github.com/Dviros">Dviros (@dviros)</a>
- <a href="https://github.com/LearnerZone">LearnerZone (@learnerzone)</a>

## Contributors
- <a href="https://github.com/Dagdelo">Dagdelo</a>
- <a href="https://github.com/moneak">moneak</a>
- <a href="https://github.com/Ubop0202">Ubop0202</a>
- <a href="https://github.com/Dagdelo">Dagdelo</a>
- <a href="https://github.com/DarkNoobHunter">DarkNoobHunter</a>
- <a href="https://github.com/JEAN17RUS">JEAN17RUS</a>
- <a href="https://github.com/shaunakganorkar">shaunakganorkar</a>
- <a href="https://github.com/Rostam300">Rostam300</a>
- <a href="https://github.com/badboy051">badboy051</a>
- <a href="https://github.com/viviaja">viviaja</a>
- <a href="https://github.com/PulkitSingh256">PulkitSingh256</a>
    
    *People who have reposted, posted spam or anything useless won't appear here. May have missed some people*