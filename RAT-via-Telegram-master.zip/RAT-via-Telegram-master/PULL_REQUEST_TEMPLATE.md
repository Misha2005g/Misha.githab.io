# Pull Request Template

## Please follow this format by copying and pasting or otherwise

Describe this request in around 8 words or less: 

_________________

Does this request fix an issue, add a feature or otherwise (what is the purpose of the request): 

If this is related to an issue, specify the issue in hand: 

If this is related to a commit, specify the commit in hand: 

If this adds a feature, specify the feature you are adding/improving: 
_________________
Give a detailed description of what the PR contains, and the reasoning behind it: 
