# Rat-Python-with-telegram-
Rat Python with telegram  &lt;a open source Rat>
1) creat a bot in botfather and replace bot token to 'your token'

2)replace you id in 'id' exp===>  admin = 'xxxxx'

3)enjoy!

you need know this commands:

/dir c://

==show contents of directory and files

/dfile c://log.txt

==download log file 

my channel in telegram: https://t.me/zeroday_Exploit
