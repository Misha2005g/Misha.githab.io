<p align="center">
<img src="https://a.imagem.app/Kemhb.png" width="140" alt="TelegramRAT"></p>

## Compiling
```
pyinstaller --icon YOUR_ICON --noconsole -F main.py
```
## info
##### --icon YOUR_ICON 
###### Uses the icon in the format .ICO
##### --noconsole
###### Does not show the console while the program is running
##### -F
###### Compiles the file in .exe
